A Pen created at CodePen.io. You can find this one at https://codepen.io/NilsWe/pen/FemfK.

 Fully responsive CSS Timeline.

Full article with explanation: http://nilswe.com/lab/css-timeline/